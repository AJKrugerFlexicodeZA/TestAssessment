﻿// Services/EnrollmentService.cs
using StudentEnrollmentAPI.Data;
using StudentEnrollmentAPI.Interfaces;
using MIDTIER.Models;
using static MIDTIER.Models.DTOs;
using StudentCourseEnrollments.Services.StudentCourseEnrollments.Services;
using System.Collections.Generic;

namespace StudentEnrollmentAPI.Services
{
    public class EnrollmentService : IEnrollmentService
    {
        private static readonly Dictionary<int, int> _courseEnrollmentCount = new();

        private static void UpdateCache(int courseId, int delta)
        {
            if (_courseEnrollmentCount.TryGetValue(courseId, out var count))
            {
                if (count + delta <= 0)
                    _courseEnrollmentCount.Remove(courseId);
                else
                    _courseEnrollmentCount[courseId] = count + delta;
            }
            else if (delta > 0)
            {
                _courseEnrollmentCount[courseId] = delta;
            }
        }

        public AppResponse<List<Enrollment>> GetAllEnrollments(int updateUserId)
        {
            List<Enrollment> list = new();

            foreach (var (userId, courseIds) in DataStore.Enrollments)
            {
                var user = DataStore.Users.GetValueOrDefault(userId);

                foreach (var courseId in courseIds)
                {
                    var course = DataStore.Courses.GetValueOrDefault(courseId);
                    list.Add(new Enrollment {
                        EnrolledAt = DateTime.UtcNow,
                        User = user,
                        Course = course,
                        UserId = userId,
                        CourseId = courseId
                    });
                }
            }

            if(list.Count > 0)
            {
                LogService.Info($"User retrieved [{list.Count}] records", "Enrollments", updateUserId);
                return new AppResponse<List<Enrollment>>
                {
                    Code = 200,
                    Message = "Success",
                    Success = true,
                    Data = list,
                    Error = null
                };
            }

            LogService.Info($"User retrieved [{list.Count}] records", "Enrollments", updateUserId);
            return new AppResponse<List<Enrollment>>
            {
                 Code = 404,
                 Message = "No enrollments found",
                 Success = false,
                 Data = null,
                 Error = "No enrollments available in the system"
            };
        }

        public AppResponse GetEnrollmentsByUserId(int userId,int updateUserId)
        {
            if (!DataStore.Enrollments.TryGetValue(userId, out var courseIds))
            {
                LogService.Info($"User retrieved [0] records for UserId [{userId}]", "Enrollments", updateUserId);
                return new AppResponse
                {
                    Code = 404,
                    Message = "No enrollments found for the user",
                    Success = false,
                    Data = null,
                    Error = null
                };
            }

            var result = new List<Enrollment>(courseIds.Count);
            foreach (var courseId in courseIds)
            {
                var course = DataStore.Courses.GetValueOrDefault(courseId);
                result.Add(new Enrollment { 
                    UserId = userId,
                    CourseId = courseId,
                    EnrolledAt = DateTime.UtcNow,
                    Course = course
                });
            }
            LogService.Info($"User retrieved [{result.Count}] records for UserId [{userId}]", "Enrollments", updateUserId);
            return new AppResponse{
                Code = 200,
                Message = "Success",
                Success = true,
                Data = result,
                Error = null
            };
        }

        public AppResponse<List<Enrollment.EnrolledCourses>> GetEnrolledCourses(int userId, int updateUserId)
        {
            // Validate the requesting user exists
            if (!DataStore.Users.TryGetValue(updateUserId, out var currentUser))
            {
                LogService.Warn($"Requesting user {updateUserId} not found", "Enrollments", updateUserId);
                return new AppResponse<List<Enrollment.EnrolledCourses>>
                {
                    Code = 404,
                    Success = false,
                    Message = "User not found"
                };
            }

            LogService.Info($"GetEnrolledCourses called by {currentUser.Role} (ID: {updateUserId})", "Enrollments", updateUserId);

            //Admin sees all courses, Student sees only their enrolled ones
            var result = (
                from course in DataStore.Courses.Values
                where course.IsActive

                //Count how many students are enrolled in this course
                let totalStudents = DataStore.Enrollments
                    .Count(e => e.Value.Contains(course.Id))

                //Check if current user (student) is enrolled in this course
                let isEnrolled = currentUser.Role == Roles.student &&
                                 DataStore.Enrollments.TryGetValue(updateUserId, out var userCourses) &&
                                 userCourses.Contains(course.Id)

                //ROLE FILTER: Admin sees all, Student sees only enrolled
                where currentUser.Role == Roles.admin || isEnrolled

                orderby course.Title

                select new Enrollment.EnrolledCourses
                {
                    CourseId = course.Id,
                    Title = course.Title ?? "Unknown Course",
                    Description = course.Description ?? "No description available",
                    TotalUsers = totalStudents
                    // No InstructorName — you said you don't use instructors
                }
            ).ToList();

            if (result.Count > 0)
            {
                LogService.Info($"Retrieved {result.Count} course(s) for {currentUser.Role} (ID: {updateUserId})",
                    "Enrollments", updateUserId);

                return new AppResponse<List<Enrollment.EnrolledCourses>>
                {
                    Code = 200,
                    Success = true,
                    Message = "Success",
                    Data = result
                };
            }

            LogService.Info($"No courses found for {currentUser.Role} (ID: {updateUserId})",
                "Enrollments", updateUserId);

            return new AppResponse<List<Enrollment.EnrolledCourses>>
            {
                Code = 404,
                Success = false,
                Message = "No courses found",
                Data = new()
            };
        }
        public AppResponse EnrollUser(int userId, int courseId,int updateUserId)
        {
            if (!DataStore.Users.ContainsKey(userId) || !DataStore.Courses.ContainsKey(courseId))
            {
                LogService.Error($"Error 404 : User [{userId}] or Course [{courseId}] not found", "Enrollments", updateUserId);
                return new AppResponse
                {
                    Code = 404,
                    Message = "User or Course not found",
                    Success = false,
                    Data = null,
                    Error = "Either the user or the course does not exist"
                };
            }        

            if (!DataStore.Enrollments.TryGetValue(userId, out var set))
            {
                set = new HashSet<int>();
                DataStore.Enrollments[userId] = set;
            }

            if (set.Add(courseId))
            {
                UpdateCache(courseId, +1);
                LogService.Info($"User [{userId}] enrolled in Course [{courseId}]", "Enrollments", updateUserId);
                return new AppResponse { 
                    Code = 201,
                    Message = "Enrolled successfully",
                    Success = false,
                    Data = null,
                    Error = null
                };
            }
            LogService.Error($"Error 409 : User [{userId}] already enrolled in Course [{courseId}]", "Enrollments", updateUserId);
            return new AppResponse { 
                Code = 409,
                Message = "Already enrolled",
                Success = false,
                Data = null,
                Error = "The user is already enrolled in the course"
            };
        }

        public AppResponse UnenrollUser(int userIdToRemove, int courseId, int requestingUserId)
        {
            // 1. Validate the user who is making the request
            if (!DataStore.Users.TryGetValue(requestingUserId, out var requestingUser))
            {
                LogService.Warn($"Requesting user {requestingUserId} not found", "Enrollments", requestingUserId);
                return new AppResponse
                {
                    Code = 404,
                    Success = false,
                    Message = "Requesting user not found"
                };
            }

            // 2. ROLE CHECK: Student can only unenroll themselves
            if (requestingUser.Role == Roles.student && userIdToRemove != requestingUserId)
            {
                LogService.Warn($"Student {requestingUserId} tried to unenroll another user {userIdToRemove}",
                    "Enrollments", requestingUserId);

                return new AppResponse
                {
                    Code = 403,
                    Success = false,
                    Message = "Forbidden",
                    Error = "Students can only unenroll themselves"
                };
            }

            // 3. Admin can unenroll anyone — no restriction
            // (If we reach here and it's admin → allowed)

            // 4. Perform the actual unenrollment
            if (!DataStore.Enrollments.TryGetValue(userIdToRemove, out var enrolledCourses) ||
                !enrolledCourses.Remove(courseId))
            {
                LogService.Warn($"User {userIdToRemove} is not enrolled in course {courseId}",
                    "Enrollments", requestingUserId);

                return new AppResponse
                {
                    Code = 404,
                    Success = false,
                    Message = "Not enrolled",
                    Error = "The user is not enrolled in this course"
                };
            }

            // 5. If user has no more courses → remove their entry completely
            if (enrolledCourses.Count == 0)
            {
                DataStore.Enrollments.Remove(userIdToRemove);
                LogService.Info($"User {userIdToRemove} has no more enrollments — entry removed",
                    "Enrollments", requestingUserId);
            }

            // 6. Update cache (student count per course)
            UpdateCache(courseId, -1);

            // 7. Log success with context
            string actionBy = requestingUser.Role == Roles.admin
                ? $"Admin {requestingUser.Name}"
                : "Self";

            LogService.Info($"User {userIdToRemove} unenrolled from course {courseId} by {actionBy}",
                "Enrollments", requestingUserId);

            return new AppResponse
            {
                Code = 200,
                Success = true,
                Message = "Unenrolled successfully"
            };
        }

        public AppResponse IsEnrolled(int userId, int courseId,int updateUserId)
        {
            if (DataStore.Enrollments.TryGetValue(userId, out var set) && set.Contains(courseId))
            {
                LogService.Info($"User [{userId}] is enrolled in Course [{courseId}]", "Enrollments", updateUserId);
                return new AppResponse
                {
                    Code = 200,
                    Message = "User is enrolled in the course",
                    Success = true,
                    Data = true,
                    Error = null
                };
            }
            LogService.Error($"User [{userId}] is not enrolled in Course [{courseId}]", "Enrollments", updateUserId);
            return new AppResponse {
                Code = 404,
                Message = "User is not enrolled in the course",
                Success = false,
                Data = false,
                Error = null
            };
        }

        public AppResponse GetEnrollmentCountForCourse(int courseId,int updateUserId)
        {   
            if(courseId == 0)
            {
                LogService.Error($"Invalid Course Id [{courseId}]", "Enrollments", updateUserId);
                return new AppResponse
                {
                    Code = 400,
                    Message = "Invalid Course Id",
                    Success = false,
                    Data = 0,
                    Error = "Course Id cannot be zero"
                };
            }         

            var count = _courseEnrollmentCount.GetValueOrDefault(courseId);

            if (count == 0)
            {
                LogService.Info($"No enrollments found for Course Id [{courseId}]", "Enrollments", updateUserId);
                return new AppResponse
                {
                    Code = 404,
                    Message = "No enrollments found for the course",
                    Success = false,
                    Data = 0,
                    Error = null
                };
            }
            LogService.Info($"Enrollment count for Course Id [{courseId}] is [{count}]", "Enrollments", updateUserId);
            return new AppResponse
            {
                Code = 200,
                Message = "Success",
                Success = true,
                Data = count,
                Error = null
            };

        }

    }
}

