﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIDTIER.Models
{
    public class DTOs
    {
        // For /available endpoint — tells frontend if user is enrolled
        public class CourseDto {
            public int Id { get; set; }
            public string? Title { get; set; }
            public string? Description { get; set; }
            public bool IsActive { get; set; }
            public bool IsEnrolled { get; set; }
        };

        // For /enrolled endpoint
        public class EnrolledCourseDto {
            public int CourseId { get; set; }
            public string? Title { get; set; }
            public string? Description { get; set; }
            public int TotalStudents { get; set; }
        };

        // Optional: Full enrollment details (admin only)
        public class EnrollmentDto {
            public int UserId { get; set; }
            public string? UserName { get; set; }
            public int CourseId { get; set; }
            public string? CourseTitle { get; set; }
            public DateTime EnrolledAt { get; set; }
        };
    }
}
