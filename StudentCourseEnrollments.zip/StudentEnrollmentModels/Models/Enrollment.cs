﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MIDTIER.Models
{
    public class Enrollment
    {
        public int UserId { get;set; }
        public int CourseId { get; set; }
        public DateTime EnrolledAt { get; set; }
        public User? User { get;set; }
        public Course? Course { get;set; }
        // Nested DTO — exactly as you defined
        public class EnrolledCourses {
            public int CourseId { get; set; }
            public string? Title { get; set; }
            public string? Description { get; set; }
            public int TotalUsers { get; set; }
            public string? InstructorName { get; set; }
            public int? InstructorId { get; set; }
        };
    }
}
