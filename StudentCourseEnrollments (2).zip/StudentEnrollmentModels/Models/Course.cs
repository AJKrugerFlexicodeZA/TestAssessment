﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MIDTIER.Models
{
    public class Course {
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; }
        public int? InstructorId { get; set; }
    };

}
